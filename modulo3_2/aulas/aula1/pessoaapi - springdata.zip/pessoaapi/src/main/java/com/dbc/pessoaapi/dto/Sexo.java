package com.dbc.pessoaapi.dto;

public enum Sexo {
    M,F
}
