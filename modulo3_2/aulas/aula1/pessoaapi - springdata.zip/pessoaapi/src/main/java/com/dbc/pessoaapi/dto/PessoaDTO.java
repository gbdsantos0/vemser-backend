package com.dbc.pessoaapi.dto;

import lombok.Data;

@Data
public class PessoaDTO extends PessoaCreateDTO {
    private Integer idPessoa;
}