package com.dbc.chatkafkaparticao.exception;

public class RegraDeNegocioException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4127776567900488040L;

	public RegraDeNegocioException(String message) {
        super(message);
	}
	
}
