package com.dbc.chatkafkaparticao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatKafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
