package com.dbc.produtorconsumidor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProdutorConsumidorApplicationTests {

	@Test
	void contextLoads() {
	}

}
