package com.dbc.aulamodulo3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aulamodulo3Application {

	public static void main(String[] args) {
		SpringApplication.run(Aulamodulo3Application.class, args);
	}

}
